-- phpMyAdmin SQL Dump
-- version 
-- http://www.phpmyadmin.net
--
-- Хост: u49636.mysql.masterhost.ru
-- Время создания: Апр 18 2013 г., 12:17
-- Версия сервера: 5.0.95
-- Версия PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `u49636`
--

-- --------------------------------------------------------

--
-- Структура таблицы `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `Id` int(11) NOT NULL auto_increment,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `GroupId` int(11) NOT NULL,
  PRIMARY KEY  (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `customers`
--

INSERT INTO `customers` (`Id`, `Name`, `Email`, `GroupId`) VALUES
(1, 'Bolseo', 'flyerex@gmail.com', 5),
(3, 'Bolseo', 'nicewebmaster@mail.ru', 5),
(4, 'Bolseo', 'flyerex@yandex.ru', 5),
(6, 'Bolseo', 'ignatenko.evgeniy@gmail.com', 5),
(7, 'РїСЂРёРјРµСЂ1', 'mailtest@nobody.ru', 8),
(8, 'РїСЂРёРјРµСЂ2', 'mailtest2@nobody.ru', 8),
(15, '', '', 9);
